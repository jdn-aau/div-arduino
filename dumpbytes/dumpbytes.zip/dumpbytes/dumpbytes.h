#ifndef DUMPB
#define DUMPB

void dumpBytes(void *p, int antal, char dType);
void dumpBytesRev(void *p, int antal,char Type);
#endif
